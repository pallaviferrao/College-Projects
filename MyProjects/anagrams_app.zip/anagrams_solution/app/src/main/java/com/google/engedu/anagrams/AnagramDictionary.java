package com.google.engedu.anagrams;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;

public class AnagramDictionary {

    private static final int MIN_NUM_ANAGRAMS = 5;
    private static final int DEFAULT_WORD_LENGTH = 3;
    private static final int MAX_WORD_LENGTH = 7;
    private Random random = new Random();
    private HashSet<String> wordSet;
    private ArrayList<String> wordList;
    private HashMap<String, ArrayList<String>> lettersToWord;
    private HashMap<Integer,ArrayList<String>> sizeToWord;
    private int wordLength;

    private String keyGenerator(String s)
    {
        char[] letters = s.toCharArray();
        Arrays.sort(letters);
        return new String(letters);
    }

    public AnagramDictionary(InputStream wordListStream) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(wordListStream));
        String line;
        wordSet = new HashSet<>();
        wordList = new ArrayList<>();
        lettersToWord = new HashMap<>();
        sizeToWord = new HashMap<>();
        wordLength = DEFAULT_WORD_LENGTH;

        while((line = in.readLine()) != null) {
            String word = line.trim();

            //add to wordSet and wordList using standard methods
            wordList.add(word);
            wordSet.add(word);

            //find key using a helper method that sorts letters in alphabetical order
            String wordKey = keyGenerator(word);

            ArrayList<String> anagrams = lettersToWord.get(wordKey);
            if (anagrams == null) {
                anagrams = new ArrayList<String>();
                lettersToWord.put(wordKey, anagrams);
            }
            anagrams.add(word);

            //add to sizeToWord map
            ArrayList<String> sameSized = sizeToWord.get(word.length());
            if (sameSized == null) {
                sameSized = new ArrayList<String>();
                sizeToWord.put(word.length(), sameSized);
            }
            sameSized.add(word);


        }

        //Log.d("Constructed: ",Integer.toString(lettersToWord.size())); 58652
    }

    public boolean isGoodWord(String word, String base) {

        //check if word exists in wordSet first
        //now check if it doesn't contain the base as a substring
        /*
             if(wordSet.contains(word))
            {
                //now check if it doesn't contain the base as a substring
                if(word.contains(base))
                    return false;
                else
                    return true;

            }
            return false;
        */

        return wordSet.contains(word) && !word.contains(base);
    }

    public ArrayList<String> getAnagramsWithOneMoreLetter(String word) {
        ArrayList<String> result = new ArrayList<String>();

        // find the key for anagrams map from given word + 1 alphabet and add all anagrams matching to result set.
        for (char i = 'a'; i <= 'z'; i++) {

            String testString = word+i;
            String genKey = keyGenerator(testString);

            if(lettersToWord.containsKey(genKey)) {
                ArrayList<String> anagrams = lettersToWord.get(genKey);
                //Log.d("Dictionary values",anagrams.toString());
                result.addAll(anagrams);

            }
        }

        //include only those words that are valid solutions in anagrams.
        ArrayList<String> solution = (ArrayList<String>) result.clone();
        for (String anagramword:result) {
            if(!isGoodWord(anagramword,word))
                solution.remove(anagramword);
        }
        result =(ArrayList<String>) solution.clone();

        return result;
    }

    public String pickGoodStarterWord() {

        boolean found = false;
        String selectedWord = "post";
        ArrayList<String> currentList = sizeToWord.get(wordLength);

        if(wordLength<=MAX_WORD_LENGTH)
            wordLength+=1; //increment starting word length for next time until we reach max_word_length

        int index = random.nextInt(currentList.size() + 1); //get an index from 0 to Size
        for(int i=index;!found;i++)
        {
            if(i>=currentList.size()) i = 0;
            if(getAnagramsWithOneMoreLetter(currentList.get(i)).size() >= MIN_NUM_ANAGRAMS){
                selectedWord=currentList.get(i);
                found=true;
            }

        }

        return selectedWord;
    }
}
